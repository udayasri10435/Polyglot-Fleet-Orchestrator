import React, { useState, useEffect } from "react";
import { 
  Activity, 
  Database, 
  Server, 
  ShieldCheck, 
  Zap, 
  Search, 
  Filter, 
  RefreshCw,
  Cpu,
  Globe,
  BarChart3,
  Car,
  X,
  Terminal,
  History,
  Clock,
  ChevronRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from "recharts";
import { Service, Stats, PricingResponse, ServiceDetail } from "./types";
import { cn } from "./lib/utils";

export default function App() {
  const [services, setServices] = useState<Service[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");
  const [selectedDomain, setSelectedDomain] = useState<string>("All");
  const [pricingResult, setPricingResult] = useState<PricingResponse | null>(null);
  const [pricingLoading, setPricingLoading] = useState(false);

  const [selectedService, setSelectedService] = useState<ServiceDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [svcRes, statsRes] = await Promise.all([
        fetch("/api/services"),
        fetch("/api/stats")
      ]);

      if (!svcRes.ok) {
        const text = await svcRes.text();
        throw new Error(`Services API error (${svcRes.status}): ${text.slice(0, 100)}`);
      }
      if (!statsRes.ok) {
        const text = await statsRes.text();
        throw new Error(`Stats API error (${statsRes.status}): ${text.slice(0, 100)}`);
      }

      const svcData = await svcRes.json();
      const statsData = await statsRes.json();
      setServices(svcData);
      setStats(statsData);
    } catch (error) {
      console.error("Failed to fetch data", error);
      // Optionally show a toast or error state in UI
    } finally {
      setLoading(false);
    }
  };

  const fetchServiceDetail = async (id: string) => {
    setDetailLoading(true);
    try {
      const res = await fetch(`/api/services/${id}`);
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Service detail API error (${res.status}): ${text.slice(0, 100)}`);
      }
      const data = await res.json();
      setSelectedService(data);
    } catch (error) {
      console.error("Failed to fetch service detail", error);
    } finally {
      setDetailLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, []);

  const handlePricingSimulation = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setPricingLoading(true);
    const formData = new FormData(e.currentTarget);
    const payload = {
      vehicleType: formData.get("vehicleType"),
      location: formData.get("location"),
      demandLevel: formData.get("demandLevel"),
    };

    try {
      const res = await fetch("/api/ai/pricing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Pricing API error (${res.status}): ${text.slice(0, 100)}`);
      }
      const data = await res.json();
      setPricingResult(data);
    } catch (error) {
      console.error("Pricing simulation failed", error);
    } finally {
      setPricingLoading(false);
    }
  };

  const filteredServices = services.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(filter.toLowerCase()) || 
                         s.id.toLowerCase().includes(filter.toLowerCase());
    const matchesDomain = selectedDomain === "All" || s.domain === selectedDomain;
    return matchesSearch && matchesDomain;
  });

  const domains = ["All", "Fleet Management", "Reservations & Pricing", "Customer Management", "Payments & Billing", "Rental Operations", "Analytics & Reporting", "Infrastructure"];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-[var(--color-line)] p-4 flex justify-between items-center bg-[var(--color-bg)] sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[var(--color-ink)] flex items-center justify-center rounded-sm">
            <Car className="text-[var(--color-bg)] w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tighter uppercase">Polyglot Fleet Orchestrator</h1>
            <p className="text-[10px] font-mono opacity-50">SYSTEM STATUS: NOMINAL // NODES: 1000 // REGION: GLOBAL-AS-1</p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-right hidden md:block">
            <p className="text-[10px] font-mono opacity-50 uppercase">Uptime</p>
            <p className="text-sm font-mono font-bold">99.9992%</p>
          </div>
          <button 
            onClick={fetchData}
            className="p-2 border border-[var(--color-line)] hover:bg-[var(--color-ink)] hover:text-[var(--color-bg)] transition-colors"
          >
            <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
          </button>
        </div>
      </header>

      <main className="flex-1 grid grid-cols-1 lg:grid-cols-[1fr_400px] overflow-hidden">
        {/* Left Column: Service Grid */}
        <div className="flex flex-col border-r border-[var(--color-line)] overflow-hidden">
          {/* Stats Bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 border-b border-[var(--color-line)]">
            <StatBox icon={<Server className="w-4 h-4" />} label="Total Services" value={stats?.total || 0} />
            <StatBox icon={<ShieldCheck className="w-4 h-4 text-emerald-600" />} label="Healthy" value={stats?.healthy || 0} />
            <StatBox icon={<Activity className="w-4 h-4 text-rose-600" />} label="Degraded" value={stats?.degraded || 0} />
            <StatBox icon={<Zap className="w-4 h-4 text-amber-500" />} label="Avg Latency" value={`${stats?.avgLatency || 0}ms`} />
          </div>

          {/* Filters */}
          <div className="p-4 border-b border-[var(--color-line)] flex flex-wrap gap-4 items-center bg-white/50">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 opacity-30" />
              <input 
                type="text" 
                placeholder="Filter services by ID or Name..."
                className="w-full pl-10 pr-4 py-2 bg-transparent border border-[var(--color-line)] text-sm font-mono focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 opacity-30" />
              <select 
                className="bg-transparent border border-[var(--color-line)] text-xs font-mono py-2 px-3 focus:outline-none"
                value={selectedDomain}
                onChange={(e) => setSelectedDomain(e.target.value)}
              >
                {domains.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
          </div>

          {/* Table Header */}
          <div className="grid grid-cols-[40px_1.5fr_1fr_1fr_1fr_80px] p-3 border-b border-[var(--color-line)] bg-[var(--color-ink)] text-[var(--color-bg)]">
            <div className="col-header text-[var(--color-bg)] opacity-100">#</div>
            <div className="col-header text-[var(--color-bg)] opacity-100">Service Name</div>
            <div className="col-header text-[var(--color-bg)] opacity-100">Domain</div>
            <div className="col-header text-[var(--color-bg)] opacity-100">Stack</div>
            <div className="col-header text-[var(--color-bg)] opacity-100">Version</div>
            <div className="col-header text-[var(--color-bg)] opacity-100">Status</div>
          </div>

          {/* Table Body */}
          <div className="flex-1 overflow-y-auto">
            {loading && services.length === 0 ? (
              <div className="p-20 text-center font-mono animate-pulse text-xs opacity-50">INITIALIZING SERVICE MESH...</div>
            ) : (
              filteredServices.slice(0, 100).map((s, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.01 }}
                  key={s.id} 
                  className="data-row group"
                  onClick={() => fetchServiceDetail(s.id)}
                >
                  <div className="data-value opacity-30">{i + 1}</div>
                  <div className="data-value font-bold flex items-center gap-2">
                    {s.name}
                    <ChevronRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="data-value opacity-70">{s.domain}</div>
                  <div className="data-value">
                    <span className={cn(
                      "px-1.5 py-0.5 border rounded-sm text-[9px] font-bold uppercase",
                      s.language === "Rust" && "border-orange-500 text-orange-600",
                      s.language === "Go" && "border-cyan-500 text-cyan-600",
                      s.language === "Python" && "border-yellow-500 text-yellow-600",
                      s.language === "Node.js" && "border-green-500 text-green-600",
                      s.language === "Java" && "border-red-500 text-red-600",
                    )}>
                      {s.language}
                    </span>
                  </div>
                  <div className="data-value opacity-50">{s.version}</div>
                  <div className="flex items-center">
                    <span className={cn(
                      "status-pill",
                      s.status === "healthy" ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                    )}>
                      {s.status}
                    </span>
                  </div>
                </motion.div>
              ))
            )}
            {filteredServices.length > 100 && (
              <div className="p-4 text-center text-[10px] font-mono opacity-30 uppercase">
                Showing first 100 of {filteredServices.length} services...
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Analytics & AI */}
        <aside className="bg-white/30 backdrop-blur-sm flex flex-col overflow-y-auto">
          {/* Domain Distribution Chart */}
          <div className="p-6 border-b border-[var(--color-line)]">
            <h3 className="text-xs font-serif italic mb-4 flex items-center gap-2">
              <BarChart3 className="w-3 h-3" /> Domain Distribution
            </h3>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats?.domainDistribution || []} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#14141420" />
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    width={100} 
                    tick={{ fontSize: 9, fontFamily: 'monospace' }} 
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#141414', border: 'none', color: '#E4E3E0', fontSize: '10px', fontFamily: 'monospace' }}
                    itemStyle={{ color: '#F27D26' }}
                  />
                  <Bar dataKey="count" fill="#141414" radius={[0, 2, 2, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* AI Dynamic Pricing Simulator */}
          <div className="p-6 border-b border-[var(--color-line)]">
            <h3 className="text-xs font-serif italic mb-4 flex items-center gap-2">
              <Cpu className="w-3 h-3" /> AI Pricing Microservice (v2.5)
            </h3>
            <form onSubmit={handlePricingSimulation} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold opacity-50">Vehicle Type</label>
                  <select name="vehicleType" className="w-full bg-transparent border border-[var(--color-line)] p-2 text-xs font-mono">
                    <option>Economy Sedan</option>
                    <option>Luxury SUV</option>
                    <option>Electric Hatchback</option>
                    <option>Convertible Sport</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold opacity-50">Demand Level</label>
                  <select name="demandLevel" className="w-full bg-transparent border border-[var(--color-line)] p-2 text-xs font-mono">
                    <option>Low</option>
                    <option>Normal</option>
                    <option>High</option>
                    <option>Peak (Holiday)</option>
                  </select>
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold opacity-50">Location</label>
                <input 
                  name="location" 
                  defaultValue="San Francisco, CA"
                  className="w-full bg-transparent border border-[var(--color-line)] p-2 text-xs font-mono"
                />
              </div>
              <button 
                type="submit"
                disabled={pricingLoading}
                className="w-full py-2 bg-[var(--color-ink)] text-[var(--color-bg)] text-xs font-bold uppercase tracking-widest hover:bg-[var(--color-accent)] transition-colors disabled:opacity-50"
              >
                {pricingLoading ? "CALCULATING..." : "GENERATE AI QUOTE"}
              </button>
            </form>

            <AnimatePresence>
              {pricingResult && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-4 p-4 border border-dashed border-[var(--color-line)] bg-[var(--color-accent)]/10"
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-bold uppercase">Quote Result</span>
                    <span className="text-xl font-mono font-bold">{pricingResult.currency}{pricingResult.price}</span>
                  </div>
                  <p className="text-[10px] font-mono leading-relaxed opacity-80 italic">
                    "{pricingResult.reasoning}"
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* System Health Overview */}
          <div className="p-6">
            <h3 className="text-xs font-serif italic mb-4 flex items-center gap-2">
              <Globe className="w-3 h-3" /> Global Mesh Health
            </h3>
            <div className="space-y-3">
              <HealthBar label="Database Cluster (PostgreSQL)" percentage={98} />
              <HealthBar label="Kafka Event Bus" percentage={100} />
              <HealthBar label="API Gateway (Envoy)" percentage={99} />
              <HealthBar label="Auth Service (OAuth2)" percentage={97} />
            </div>
          </div>
        </aside>
      </main>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedService && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedService(null)}
              className="absolute inset-0 bg-[var(--color-ink)]/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-4xl max-h-[90vh] bg-[var(--color-bg)] border border-[var(--color-line)] flex flex-col overflow-hidden shadow-2xl"
            >
              {/* Modal Header */}
              <div className="p-6 border-b border-[var(--color-line)] flex justify-between items-start bg-[var(--color-ink)] text-[var(--color-bg)]">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <span className="text-[10px] font-mono opacity-50 uppercase tracking-widest">{selectedService.id}</span>
                    <span className={cn(
                      "status-pill",
                      selectedService.status === "healthy" ? "bg-emerald-500 text-white" : "bg-rose-500 text-white"
                    )}>
                      {selectedService.status}
                    </span>
                  </div>
                  <h2 className="text-3xl font-bold uppercase tracking-tighter">{selectedService.name}</h2>
                  <p className="text-xs font-mono opacity-70 mt-1">{selectedService.domain} // {selectedService.language} STACK</p>
                </div>
                <button 
                  onClick={() => setSelectedService(null)}
                  className="p-2 hover:bg-[var(--color-bg)] hover:text-[var(--color-ink)] transition-colors rounded-sm"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Modal Content */}
              <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-[1fr_300px]">
                <div className="p-6 space-y-8">
                  {/* Real-time Logs */}
                  <section>
                    <h3 className="text-xs font-serif italic mb-4 flex items-center gap-2 uppercase tracking-widest">
                      <Terminal className="w-3 h-3" /> Live Event Stream
                    </h3>
                    <div className="bg-[var(--color-ink)] text-[var(--color-bg)] p-4 font-mono text-[10px] space-y-2 rounded-sm border border-[var(--color-line)] max-h-[200px] overflow-y-auto">
                      {selectedService.logs.map((log, i) => (
                        <div key={i} className="flex gap-3">
                          <span className="opacity-30">[{log.timestamp.split('T')[1].split('.')[0]}]</span>
                          <span className={cn(
                            "font-bold",
                            log.level === "ERROR" ? "text-rose-400" : log.level === "WARN" ? "text-amber-400" : "text-emerald-400"
                          )}>{log.level}</span>
                          <span className="opacity-80">{log.message}</span>
                        </div>
                      ))}
                    </div>
                  </section>

                  {/* Version History */}
                  <section>
                    <h3 className="text-xs font-serif italic mb-4 flex items-center gap-2 uppercase tracking-widest">
                      <History className="w-3 h-3" /> Deployment History
                    </h3>
                    <div className="space-y-4">
                      {selectedService.history.map((h, i) => (
                        <div key={i} className="flex gap-4 items-start">
                          <div className="w-16 text-[10px] font-mono opacity-50 pt-1">{h.date}</div>
                          <div className="flex-1 border-l border-[var(--color-line)] pl-4 pb-4">
                            <div className="text-xs font-bold font-mono">{h.version}</div>
                            <p className="text-[10px] opacity-70 mt-1 italic leading-relaxed">{h.changes}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </section>
                </div>

                {/* Sidebar Metrics */}
                <aside className="p-6 border-l border-[var(--color-line)] bg-white/20 space-y-8">
                  <section>
                    <h3 className="text-[10px] font-bold uppercase opacity-50 mb-4 flex items-center gap-2">
                      <Activity className="w-3 h-3" /> Resource Metrics
                    </h3>
                    <div className="space-y-6">
                      <MetricItem label="CPU Usage" value={`${selectedService.metrics.cpu}%`} percentage={selectedService.metrics.cpu} />
                      <MetricItem label="Memory" value={`${selectedService.metrics.memory}MB`} percentage={(selectedService.metrics.memory / 1024) * 100} />
                      <MetricItem label="Requests/sec" value={selectedService.metrics.requests} percentage={(selectedService.metrics.requests / 2000) * 100} />
                    </div>
                  </section>

                  <section>
                    <h3 className="text-[10px] font-bold uppercase opacity-50 mb-4 flex items-center gap-2">
                      <Clock className="w-3 h-3" /> Availability
                    </h3>
                    <div className="p-4 border border-[var(--color-line)] bg-[var(--color-bg)]">
                      <div className="text-2xl font-mono font-bold">99.99%</div>
                      <div className="text-[9px] opacity-50 uppercase mt-1">Last 30 Days</div>
                    </div>
                  </section>
                </aside>
              </div>

              {/* Modal Footer */}
              <div className="p-4 border-t border-[var(--color-line)] bg-white/50 flex justify-end gap-3">
                <button 
                  className="px-4 py-2 border border-[var(--color-line)] text-[10px] font-bold uppercase hover:bg-[var(--color-ink)] hover:text-[var(--color-bg)] transition-colors"
                  onClick={() => setSelectedService(null)}
                >
                  Close Inspector
                </button>
                <button className="px-4 py-2 bg-[var(--color-ink)] text-[var(--color-bg)] text-[10px] font-bold uppercase hover:bg-[var(--color-accent)] transition-colors">
                  Restart Service
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="border-t border-[var(--color-line)] p-2 bg-[var(--color-ink)] text-[var(--color-bg)] flex justify-between items-center text-[9px] font-mono uppercase tracking-widest">
        <div>© 2026 Fleet-Orchestrator-Global // All Rights Reserved</div>
        <div className="flex gap-4">
          <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div> All Systems Operational</span>
          <span>v4.12.0-stable</span>
        </div>
      </footer>
    </div>
  );
}

function StatBox({ icon, label, value }: { icon: React.ReactNode, label: string, value: string | number }) {
  return (
    <div className="p-4 border-r border-[var(--color-line)] last:border-r-0">
      <div className="flex items-center gap-2 opacity-50 mb-1">
        {icon}
        <span className="text-[10px] uppercase font-bold tracking-tighter">{label}</span>
      </div>
      <div className="text-2xl font-mono font-bold tracking-tighter">{value}</div>
    </div>
  );
}

function HealthBar({ label, percentage }: { label: string, percentage: number }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-[9px] font-mono uppercase">
        <span>{label}</span>
        <span>{percentage}%</span>
      </div>
      <div className="h-1 bg-[var(--color-ink)]/10 w-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          className={cn(
            "h-full",
            percentage > 95 ? "bg-emerald-500" : percentage > 80 ? "bg-amber-500" : "bg-rose-500"
          )}
        />
      </div>
    </div>
  );
}

function MetricItem({ label, value, percentage }: { label: string, value: string | number, percentage: number }) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-end">
        <span className="text-[10px] font-mono opacity-50 uppercase">{label}</span>
        <span className="text-sm font-mono font-bold">{value}</span>
      </div>
      <div className="h-1.5 bg-[var(--color-ink)]/5 w-full rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(percentage, 100)}%` }}
          className="h-full bg-[var(--color-ink)]"
        />
      </div>
    </div>
  );
}
