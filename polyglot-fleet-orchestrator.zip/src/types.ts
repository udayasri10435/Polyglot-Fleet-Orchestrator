export interface Service {
  id: string;
  name: string;
  domain: string;
  language: string;
  status: "healthy" | "degraded";
  latency: number;
  version: string;
}

export interface Stats {
  total: number;
  healthy: number;
  degraded: number;
  avgLatency: number;
  domainDistribution: { name: string; count: number }[];
}

export interface PricingResponse {
  price: number;
  currency: string;
  reasoning: string;
}

export interface LogEntry {
  timestamp: string;
  level: "INFO" | "WARN" | "ERROR";
  message: string;
}

export interface VersionHistory {
  version: string;
  date: string;
  changes: string;
}

export interface ServiceDetail extends Service {
  logs: LogEntry[];
  history: VersionHistory[];
  metrics: {
    cpu: number;
    memory: number;
    requests: number;
  };
}
