import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // Initialize Gemini for AI-driven services
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

  // Simulated Service Registry Data
  const domains = [
    "Fleet Management",
    "Reservations & Pricing",
    "Customer Management",
    "Payments & Billing",
    "Rental Operations",
    "Analytics & Reporting",
    "Infrastructure",
  ];

  const languages = ["Rust", "Go", "Java", "Python", "Node.js", "C++", "C#", "Scala"];

  const services = Array.from({ length: 1000 }).map((_, i) => ({
    id: `svc-${i + 1}`,
    name: `${domains[i % domains.length].split(" ")[0]}-${i + 1}`,
    domain: domains[i % domains.length],
    language: languages[Math.floor(Math.random() * languages.length)],
    status: Math.random() > 0.02 ? "healthy" : "degraded",
    latency: Math.floor(Math.random() * 100) + 5,
    version: `v${Math.floor(Math.random() * 3)}.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}`,
  }));

  // API Routes
  app.get("/api/services", (req, res) => {
    const { domain, status } = req.query;
    let filtered = services;
    if (domain) filtered = filtered.filter(s => s.domain === domain);
    if (status) filtered = filtered.filter(s => s.status === status);
    res.json(filtered);
  });

  app.get("/api/services/:id", (req, res) => {
    const service = services.find(s => s.id === req.params.id);
    if (!service) return res.status(404).json({ error: "Service not found" });

    const logs = [
      { timestamp: new Date().toISOString(), level: "INFO", message: "Service heartbeat detected." },
      { timestamp: new Date(Date.now() - 5000).toISOString(), level: "INFO", message: "Incoming request from edge-gateway-01." },
      { timestamp: new Date(Date.now() - 15000).toISOString(), level: "WARN", message: "Latency spike detected in upstream dependency." },
      { timestamp: new Date(Date.now() - 45000).toISOString(), level: "INFO", message: "Configuration reload successful." },
      { timestamp: new Date(Date.now() - 120000).toISOString(), level: "ERROR", message: "Failed to connect to secondary database cluster." },
    ];

    const history = [
      { version: service.version, date: "2026-03-25", changes: "Initial stable release for Q1." },
      { version: "v0.9.2", date: "2026-03-10", changes: "Performance optimizations for telemetry ingestion." },
      { version: "v0.8.5", date: "2026-02-28", changes: "Security patches for gRPC communication." },
    ];

    const metrics = {
      cpu: Math.floor(Math.random() * 40) + 10,
      memory: Math.floor(Math.random() * 512) + 128,
      requests: Math.floor(Math.random() * 1000) + 200,
    };

    res.json({ ...service, logs, history, metrics });
  });

  app.get("/api/stats", (req, res) => {
    const stats = {
      total: services.length,
      healthy: services.filter(s => s.status === "healthy").length,
      degraded: services.filter(s => s.status === "degraded").length,
      avgLatency: Math.round(services.reduce((acc, s) => acc + s.latency, 0) / services.length),
      domainDistribution: domains.map(d => ({
        name: d,
        count: services.filter(s => s.domain === d).length
      }))
    };
    res.json(stats);
  });

  // AI Dynamic Pricing Simulation
  app.post("/api/ai/pricing", async (req, res) => {
    const { vehicleType, location, demandLevel } = req.body;
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `As a Dynamic Pricing Microservice, calculate a rental price for a ${vehicleType} in ${location} with a demand level of ${demandLevel}. Return ONLY a JSON object with "price", "currency", and "reasoning".`,
        config: { responseMimeType: "application/json" }
      });
      res.json(JSON.parse(response.text));
    } catch (error) {
      res.status(500).json({ error: "AI Pricing Service Unavailable" });
    }
  });

  // Catch-all for undefined API routes to prevent SPA fallback returning HTML
  app.all("/api/*", (req, res) => {
    res.status(404).json({ error: `API route not found: ${req.method} ${req.url}` });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
